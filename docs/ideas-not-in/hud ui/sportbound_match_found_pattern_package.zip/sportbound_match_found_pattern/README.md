# Sportbound Match Found HUD Pattern

This package gives you the **MATCH FOUND** UI panel as an editable, scalable pattern instead of a single locked image.

## Files

- `match-found-panel-editable.svg`  
  Full SVG with frame and editable text layer.

- `match-found-frame-only.svg`  
  Transparent HUD frame only. Use this behind live HTML/CSS/game-engine text.

- `match-found.css`  
  CSS pattern setup using the frame-only SVG as a scalable background.

- `match-found-demo.html`  
  Browser preview showing the pattern in use.

- `match-found-tokens.json`  
  Brand colors and recommended sizing.

## Best use

Use `match-found-frame-only.svg` as the resizable border/background, then place your actual text in HTML, Godot, Unity, or whatever UI layer you use.

That keeps this adjustable instead of baking the countdown into a PNG like a caveman with RGB lighting.

## Quick HTML

```html
<section class="match-found match-found--wide">
  <div class="match-found__content">
    <div class="match-found__status">MATCH FOUND</div>
    <div class="match-found__arena">ARENA: SKYDOME</div>
    <div class="match-found__timer">00:18</div>
    <div class="match-found__footer">PREPARE TO COMPETE</div>
  </div>
</section>
```

## Quick CSS

```css
.match-found::before {
  background: url("./match-found-frame-only.svg") center / 100% 100% no-repeat;
}
```

## Easy edits

Change these CSS variables:

```css
:root {
  --match-panel-width: 760px;
  --match-panel-height: 210px;
  --sb-cyan: #00E5FF;
  --sb-lime: #A8FF00;
}
```

## Game engine tip

For Godot/UI work:
1. Use `match-found-frame-only.svg` as the frame art.
2. Add Label/RichTextLabel nodes on top.
3. Anchor the text to center.
4. Animate the timer separately.
5. Use glow/bloom on cyan and lime layers if available.

## Font note

For the closest look, use your Sportbound Strike font from the previous package for headings/timers, or use Orbitron/Rajdhani as web-safe-ish substitutes.
