# Sportbound Strike — Typeface Handoff Spec

A production-oriented starter spec for the **Box 5 typography** style from the *Sportbound: Realms of Play* brand board.

## Core idea

**Sportbound Strike** is an all-caps futuristic sports-tech display face. It is built for MMO logos, arena UI, faction banners, menu headings, match cards, and short impact phrases like:

- CHAMPIONS ARE MADE HERE
- NEXT MATCH. NEW REALM. YOUR LEGEND.
- LEVEL UP. GEAR UP. STAND OUT.

The tone should feel like **chrome armor + scoreboard type + sci-fi HUD**. Not friendly. Not bubbly. No rounded SaaS nonsense. This font should look like it drank Gatorade out of a laser cannon.

## Included files

- `SportboundStrike-Regular.ttf` — installable starter font
- `SportboundStrike-Regular.woff` — web font
- `SportboundStrike-Regular.woff2` — compressed web font
- `sportbound-strike.css` — web styling to recreate the cyan/glow treatment
- `font-specimen.html` — browser preview page
- `sportbound-strike-font-spec.json` — machine-readable construction/glyph spec

## Design rules

### Shape language

- All caps only.
- Condensed, athletic, forward-moving silhouette.
- Hard chamfered corners.
- Minimal curves.
- Letters are constructed from segmented angular blocks.
- Slight forward slant to imply speed.
- Horizontal strokes should feel like armor plates or stadium signage.
- Inner counters should stay dark, narrow, and aggressive.

### Metrics

| Metric | Value |
|---|---:|
| Units per em | 1000 |
| Baseline | 0 |
| Cap height | 790 |
| Ascender | 850 |
| Descender | -150 |
| Grid | 5 x 7 modular block system |
| Cell size | 90 units |
| Gap | 12 units |
| Chamfer | 18 units |
| Slant factor | 0.10 |

### Recommended text settings

| Use | Size | Tracking | Case |
|---|---:|---:|---|
| Main heading | 64–160px | 0.06–0.10em | Uppercase |
| Subheading | 22–48px | 0.14–0.18em | Uppercase |
| Micro UI labels | 11–18px | 0.18–0.25em | Uppercase |

## Color/rendering recipe

A font file is normally monochrome. The metallic chrome, glow, and bevel from the brand board should be handled with CSS, SVG filters, or rendered image treatments.

Primary style:

```css
.sb-heading {
  font-family: "Sportbound Strike", Impact, sans-serif;
  text-transform: uppercase;
  letter-spacing: 0.075em;
  line-height: 0.92;
  color: #FFFFFF;
  -webkit-text-stroke: 1px rgba(0, 229, 255, 0.35);
  text-shadow:
    0 0 6px rgba(0, 229, 255, 0.65),
    0 0 18px rgba(0, 110, 255, 0.35),
    3px 4px 0 rgba(0, 0, 0, 0.8);
}
```

## Glyph coverage in this starter

- A–Z
- a–z maps to uppercase shapes
- 0–9
- Basic punctuation: `. , : ! ? - _ / + & #`

## Production notes

This is good enough to prototype menus, logos, headers, and game UI. It is **not** yet a finished commercial font family. Before release, refine:

1. Kerning pairs: `SP`, `PO`, `RT`, `BO`, `UN`, `ND`, `EA`, `PL`, `AY`.
2. Optical corrections for `S`, `G`, `R`, `W`, `M`, and `Q`.
3. Add proper lowercase or decide officially that the face is caps-only.
4. Add more punctuation, currency symbols, arrows, and game UI glyphs.
5. Create alternate styles: Regular, Inline, Wide, Condensed, and Outline.
6. Convert the block-cell construction into smoother custom outlines if you want a premium logo-grade font.

## Suggested family expansion

- **Sportbound Strike Regular** — current starter
- **Sportbound Strike Inline** — inner cyan cut lines
- **Sportbound Strike Chrome** — SVG/color font variant
- **Sportbound Strike Condensed** — narrow UI labels
- **Sportbound Strike Wide** — hero titles and splash screens
- **Sportbound Strike Outline** — buttons, badges, faction cards

## Naming note

The font name is original to this package. For commercial use, do a normal name/trademark clearance check and have a font designer clean up the outlines. Font law gets weird fast; do not raw-dog the launch build.
